import pandas as pd
import os, warnings, csv, json, time, re
from datetime import datetime
from config import *
from trading_signal import TradingSignalGenerator
from llm_client import FreeLLMClient
# 核心：使用增强版数据接口
from akshare_enhanced import get_stock_pool, get_stock_history

warnings.filterwarnings('ignore')

class AutoStrategyOptimizer:
    def __init__(self):
        self.llm = FreeLLMClient()
        if not os.path.exists(LOG_DIR): os.makedirs(LOG_DIR)
        
        # 打印启动时间和时间戳
        current_time = datetime.now()
        timestamp = current_time.strftime("%Y-%m-%d %H:%M:%S")
        weekday = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"][current_time.weekday()]
        
        print("=" * 80)
        print(f"🚀 AI量化选股系统启动")
        print(f"📅 运行时间: {timestamp} ({weekday})")
        print("=" * 80)
        
        # 市场环境分析
        print("📊 正在深度分析市场环境...")
        self.hot_sectors, self.market_status = self.llm.fetch_market_analysis()
        
        # 解析并美化市场状态输出
        print("\n📈 今日市场深度分析报告:")
        print("-" * 80)
        
        # 解析市场状态
        market_analysis = self._parse_market_status(self.market_status)
        
        # 输出核心建议
        print(f"🏦 核心操作建议:")
        print(f"   策略: {market_analysis.get('strategy', '观望')}")
        print(f"   仓位: {market_analysis.get('position', '5成')}")
        print(f"   理由: {market_analysis.get('reason', '市场震荡')}")
        print(f"   市场状态: {market_analysis.get('market_state', '震荡整理')}")
        
        # 输出热点板块
        if self.hot_sectors and self.hot_sectors[0] != "未知":
            print(f"\n🔥 核心热点板块:")
            for i, sector in enumerate(self.hot_sectors[:5], 1):
                print(f"   {i}. {sector}")
        else:
            print(f"\n🔍 热点监测: 暂无明确主线，关注轮动机会")
        
        # 输出详细分析
        if 'detailed_analysis' in market_analysis:
            print(f"\n📝 详细分析:")
            lines = market_analysis['detailed_analysis'].split('\n')
            for line in lines[:8]:  # 限制行数
                line = line.strip()
                if line:
                    print(f"   {line}")
            if len(lines) > 8:
                print(f"   ...")
        
        print("-" * 80)
        
        # 核心升级：多周期回测
        print("📈 正在更新历史表现数据...")
        self.update_historical_prices()
        print("🧠 正在优化因子权重配置...")
        self.weights = self._evolve_weights_via_deepseek()
        
        print(f"\n⚖️  当前因子权重配置:")
        total_weight = sum(self.weights.values())
        for factor, weight in sorted(self.weights.items(), key=lambda x: x[1], reverse=True):
            percentage = (weight / total_weight) * 100 if total_weight > 0 else 0
            print(f"   {factor:15s}: {weight:3d} ({percentage:.1f}%)")
        print("-" * 80)

    def _parse_market_status(self, status_text):
        """解析市场状态文本"""
        result = {
            'strategy': '观望',
            'position': '5成',
            'reason': '市场震荡',
            'market_state': '震荡整理',
            'detailed_analysis': ''
        }
        
        try:
            # 尝试从状态文本中提取关键信息
            lines = status_text.split('\n')
            
            for line in lines:
                line = line.strip()
                
                # 提取策略
                if '建议：' in line or '策略：' in line:
                    if '进攻' in line:
                        result['strategy'] = '进攻'
                    elif '防守' in line:
                        result['strategy'] = '防守'
                    elif '观望' in line:
                        result['strategy'] = '观望'
                
                # 提取仓位
                if '仓位：' in line:
                    import re
                    match = re.search(r'仓位：(\d+)成', line)
                    if match:
                        result['position'] = f"{match.group(1)}成"
                
                # 提取理由
                if '理由：' in line:
                    result['reason'] = line.split('理由：')[-1].strip()
                    if len(result['reason']) > 50:
                        result['reason'] = result['reason'][:50] + '...'
                
                # 提取市场状态
                if '市场状态' in line or '指数' in line:
                    if '突破' in line:
                        result['market_state'] = '突破上涨'
                    elif '下跌' in line:
                        result['market_state'] = '震荡下跌'
                    elif '整理' in line:
                        result['market_state'] = '震荡整理'
                    elif '活跃' in line:
                        result['market_state'] = '活跃上涨'
            
            # 如果没找到详细分析，使用状态文本的一部分作为详细分析
            if len(status_text) > 100:
                result['detailed_analysis'] = status_text[:200] + '...'
            
        except Exception as e:
            pass
        
        return result

    def update_historical_prices(self):
        """深度回测：追踪 T+1~T+5 表现"""
        if not os.path.exists(HIST_PATH): 
            return
        
        try:
            df = pd.read_csv(HIST_PATH, on_bad_lines='skip')
            updated = False
            today = datetime.now()
            
            if 'price_t3' not in df.columns: df['price_t3'] = 0.0
            if 'price_t5' not in df.columns: df['price_t5'] = 0.0
            
            # 只更新最近30天的记录以提高效率
            recent_records = df.tail(50)
            
            for index, row in recent_records.iterrows():
                if row['next_day_price'] == 0 or row['price_t3'] == 0:
                    try:
                        record_date = datetime.strptime(row['date'], "%Y-%m-%d")
                        days_passed = (today - record_date).days
                        
                        if days_passed > 1:
                            code = str(row['code']).zfill(6)
                            # 使用增强版获取历史数据
                            stock_df = get_stock_history(code, days=10)
                            
                            if stock_df is not None and len(stock_df) >= 2:
                                # 简单的 T+N 匹配逻辑
                                if row['next_day_price'] == 0 and len(stock_df) >= 2:
                                    df.at[index, 'next_day_price'] = stock_df.iloc[-1]['收盘']
                                    updated = True
                    except Exception as e:
                        continue
            
            if updated: 
                df.to_csv(HIST_PATH, index=False)
        except Exception as e: 
            pass

    def _evolve_weights_via_deepseek(self):
        """基于历史表现进化权重"""
        try:
            if not os.path.exists(HIST_PATH): 
                return DEFAULT_WEIGHTS
            
            df = pd.read_csv(HIST_PATH, on_bad_lines='skip')
            valid_df = df[df['next_day_price'] > 0].tail(EVOLUTION_LOOKBACK)
            
            if valid_df.empty:
                return DEFAULT_WEIGHTS
            
            history_summary = ""
            for _, row in valid_df.iterrows():
                buy = row['buy_price']
                p1 = row['next_day_price']
                ret1 = (p1 - buy) / buy * 100
                history_summary += f"{row['name']}: T+1收益:{ret1:.1f}%\n"
            
            market_ctx = f"热点:{self.hot_sectors[:3] if self.hot_sectors else '无'}, 策略:{self._parse_market_status(self.market_status).get('strategy', '观望')}, 仓位:{self._parse_market_status(self.market_status).get('position', '5成')}"
            new_weights = self.llm.optimize_weights_deep_evolution(history_summary, DEFAULT_WEIGHTS, market_ctx)
            
            return new_weights if new_weights else DEFAULT_WEIGHTS
        except Exception as e:
            return DEFAULT_WEIGHTS

    def run_daily_selection(self):
        today = datetime.now().strftime("%Y-%m-%d")
        print(f"\n🔍 开始扫描深A主板股票 (日期: {today})")
        print("📋 筛选条件:")
        print("   1. 深A主板 (00开头)")
        print("   2. 非ST股票")
        print("   3. 涨跌幅: 1.5% < 涨跌幅 < 9.7%")
        print("   4. 成交额: > 8000万")
        print("   5. 按涨跌幅排序，取前100名")
        print("-" * 80)

        try:
            # 使用多源增强接口获取池数据
            pool = get_stock_pool()
            if pool is None or pool.empty:
                print("❌ 错误：无法获取实时行情数据")
                print("💡 请检查网络连接或API状态")
                return
            
            # 检查数据列名和内容
            if '代码' not in pool.columns:
                # 尝试查找可能的代码列
                for col in pool.columns:
                    if '代码' in col or 'symbol' in col or 'Symbol' in col:
                        pool = pool.rename(columns={col: '代码'})
                        break
                
                if '代码' not in pool.columns:
                    pool['代码'] = [f"{i:06d}" for i in range(len(pool))]
            
            # 确保代码是字符串
            pool['代码'] = pool['代码'].astype(str)
            
            # 提取6位数字代码
            def extract_six_digit_code(code_str):
                if isinstance(code_str, str):
                    # 查找6位连续数字
                    match = re.search(r'(\d{6})', code_str)
                    if match:
                        return match.group(1)
                return str(code_str).zfill(6)
            
            pool['代码_6位'] = pool['代码'].apply(extract_six_digit_code)
            
            # 过滤深A主板股票（00开头）
            main_board = pool[pool['代码_6位'].str.startswith('00')].copy()
            
            if len(main_board) == 0:
                print("❌ 未找到深A主板股票")
                return
            
            # 确保数值列是数字类型
            numeric_columns = ['涨跌幅', '成交额', '最新价', '成交量']
            for col in numeric_columns:
                if col in main_board.columns:
                    main_board[col] = pd.to_numeric(main_board[col], errors='coerce').fillna(0)
                else:
                    main_board[col] = 0
            
            # 确保名称列存在
            if '名称' not in main_board.columns:
                main_board['名称'] = main_board['代码_6位'].apply(lambda x: f"股票{x}")
            
            # 第一步：过滤ST股票
            if '名称' in main_board.columns:
                st_mask = main_board['名称'].astype(str).str.contains('ST')
                main_board_no_st = main_board[~st_mask].copy()
                st_count = st_mask.sum()
                main_board = main_board_no_st
            
            if len(main_board) == 0:
                print("❌ 过滤ST后无股票")
                return
            
            # 第二步：过滤涨跌幅
            if '涨跌幅' in main_board.columns:
                change_mask = (main_board['涨跌幅'] > 1.5) & (main_board['涨跌幅'] < 9.7)
                main_board_filtered = main_board[change_mask].copy()
                change_count = (~change_mask).sum()
                main_board = main_board_filtered
            
            if len(main_board) == 0:
                print("❌ 过滤涨跌幅后无股票")
                return
            
            # 第三步：过滤成交额
            if '成交额' in main_board.columns:
                amount_mask = main_board['成交额'] > 80000000
                main_board_filtered = main_board[amount_mask].copy()
                amount_count = (~amount_mask).sum()
                main_board = main_board_filtered
            
            if len(main_board) == 0:
                print("❌ 过滤成交额后无股票")
                return
            
            # 第四步：排序
            if '涨跌幅' in main_board.columns:
                main_board = main_board.sort_values('涨跌幅', ascending=False)
            
            # 取前100只
            main_board = main_board.head(100)
            
            print(f"✅ 初步筛选完成:")
            print(f"   原始股票池: {len(pool)} 只")
            print(f"   深A主板股票: {len(main_board) + st_count if 'st_count' in locals() else 'N/A'} 只")
            print(f"   排除ST股票: {st_count if 'st_count' in locals() else 'N/A'} 只")
            print(f"   符合涨跌幅条件: {len(main_board)} 只")
            print(f"   符合成交额条件: {len(main_board) - amount_count if 'amount_count' in locals() else len(main_board)} 只")
            print("-" * 80)
            
        except Exception as e: 
            print(f"❌ 初始化股票池异常: {str(e)}")
            return

        # 分析个股
        print(f"🧠 开始深度技术分析 (共 {len(main_board)} 只股票)...")
        candidates = []
        analyzed_count = 0
        
        for idx, row in main_board.iterrows():
            try:
                code = row['代码_6位']
                name = row.get('名称', f'股票{code}')
                current_change = row.get('涨跌幅', 0)
                
                # 每分析10只股票显示一次进度
                analyzed_count += 1
                if analyzed_count % 10 == 0:
                    print(f"   ⏳ 已分析 {analyzed_count}/{len(main_board)} 只股票...")
                
                tsg = TradingSignalGenerator(code)
                tsg.fetch_stock_data()  # 这里内部也用了增强接口
                factors = tsg.get_indicators()
                
                if factors:
                    try:
                        # 准备股票信息供AI分析
                        stock_info = {
                            '代码': code,
                            '名称': name,
                            '涨跌幅': float(row.get('涨跌幅', 0)),
                            '成交额': float(row.get('成交额', 0)),
                            '最新价': float(row.get('最新价', 0)),
                            '成交量': float(row.get('成交量', 0))
                        }
                        
                        score_ai, reason_ai, alpha = self.llm.get_ai_expert_factor(json.dumps(stock_info, ensure_ascii=False))
                        factors["专家因子"] = score_ai
                        
                        # 计算总分
                        final_score = 0
                        for k in factors:
                            if k in self.weights:
                                final_score += factors[k] * self.weights.get(k, 20) / 100
                        
                        prices = tsg.calculate_logic(self.weights) 
                        
                        if prices:
                            candidates.append({
                                'code': code, 
                                'name': name, 
                                'current_price': float(row.get('最新价', 0)),
                                'change_percent': current_change,
                                '成交额': float(row.get('成交额', 0)),
                                'final_score': round(final_score + alpha, 1),
                                'ai_reason': reason_ai, 
                                **factors, 
                                **prices
                            })
                        else:
                            continue
                            
                    except Exception as e:
                        continue
                else:
                    continue
                
            except Exception as e:
                continue

        if not candidates:
            print("❌ 深度扫描后未发现符合技术面爆发要求的个股。")
            return

        top_10 = sorted(candidates, key=lambda x: x['final_score'], reverse=True)[:10]

        print("\n" + "=" * 80)
        print(f"🥇 深A主板进攻 TOP 10 (按综合评分排序)")
        print("=" * 80)
        
        for i, s in enumerate(top_10):
            print(f"\n{i+1}. {s['code']} | {s['name']}")
            print(f"   🏆 综合评分: {s['final_score']:5.1f} | 涨跌幅: {s['change_percent']:6.2f}% | 现价: {s['current_price']:7.2f} | 成交额: {s['成交额']/100000000:6.2f}亿")
            print(f"   📊 因子得分: 量价爆发:{s.get('量价爆发', 0):5.1f} 趋势强度:{s.get('趋势强度', 0):5.1f} 资金流向:{s.get('资金流向', 0):5.1f} 安全垫:{s.get('基本面安全垫', 0):5.1f} 专家因子:{s.get('专家因子', 0):5.1f}")
            
            # 简洁化AI分析理由
            ai_reason = s['ai_reason']
            if len(ai_reason) > 120:
                # 尝试提取关键信息
                lines = ai_reason.split('\n')
                short_reason = ""
                for line in lines:
                    line = line.strip()
                    if line and not line.startswith('【') and len(line) > 20:
                        short_reason = line[:100] + "..."
                        break
                if not short_reason:
                    short_reason = ai_reason[:100] + "..."
                print(f"   💡 {short_reason}")
            else:
                print(f"   💡 {ai_reason}")
            
            print(f"   📈 交易计划:")
            print(f"      今日委托买入价: {s.get('entrust_buy', 0):7.2f}")
            print(f"      T+1目标价: {s.get('target_t1', 0):7.2f} | T+2目标价: {s.get('target_t2', 0):7.2f} | T+3目标价: {s.get('target_t3', 0):7.2f}")
            print(f"      🛡️  止损价: {s.get('stop_loss', 0):7.2f}")
            
            if i < 9:
                print("   " + "-" * 70)

        print("\n" + "=" * 80)
        print("📋 操作建议:")
        print("   1. 优先选择综合评分高且AI分析逻辑清晰的个股")
        print("   2. 严格遵守买入价，避免追高")
        print("   3. 分批止盈：达到T+1目标价可减仓1/3，T+2再减1/3，T+3清仓")
        print("   4. 坚决止损：跌破止损价立即离场")
        print("   5. 单只个股仓位建议不超过总资金的15%")
        print("=" * 80)

        self._log_history(top_10)
        print(f"\n✅ 选股完成，结果已保存至历史记录")
        print(f"   选股时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    def _log_history(self, top_stocks):
        file_exists = os.path.exists(HIST_PATH)
        fieldnames = ['date', 'code', 'name', 'buy_price', 'next_day_price', 'price_t3', 'price_t5'] + list(DEFAULT_WEIGHTS.keys())
        with open(HIST_PATH, 'a', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            if not file_exists: writer.writeheader()
            for s in top_stocks:
                row = {
                    'date': datetime.now().strftime("%Y-%m-%d"), 
                    'code': s['code'], 
                    'name': s['name'], 
                    'buy_price': s.get('price', 0), 
                    'next_day_price': 0, 
                    'price_t3': 0, 
                    'price_t5': 0
                }
                for k in DEFAULT_WEIGHTS: 
                    row[k] = s.get(k, 0)
                writer.writerow(row)

if __name__ == "__main__":
    optimizer = AutoStrategyOptimizer()
    optimizer.run_daily_selection()