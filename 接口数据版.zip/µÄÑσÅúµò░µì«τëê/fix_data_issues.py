# fix_data_issues.py
import sys
import subprocess
import os

def install_packages():
    """安装或更新必要的包"""
    packages = [
        'akshare',
        'yfinance',
        'pandas',
        'numpy',
        'requests'
    ]
    
    print("📦 正在检查并安装必要的包...")
    for package in packages:
        print(f"  🔧 处理 {package}...")
        try:
            # 更新包
            subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", package])
            print(f"    ✅ {package} 安装/更新成功")
        except Exception as e:
            print(f"    ❌ {package} 安装失败: {e}")

def test_akshare():
    """测试akshare是否正常工作"""
    print("\n🧪 测试akshare...")
    try:
        import akshare as ak
        # 测试一个简单的接口
        df = ak.stock_zh_index_daily(symbol="sh000001")
        if df is not None and not df.empty:
            print(f"✅ akshare 工作正常，获取了 {len(df)} 条上证指数数据")
            return True
        else:
            print("❌ akshare 返回空数据")
            return False
    except Exception as e:
        print(f"❌ akshare 测试失败: {e}")
        return False

def test_yfinance():
    """测试yfinance是否正常工作"""
    print("\n🧪 测试yfinance...")
    try:
        import yfinance as yf
        # 测试一个股票
        stock = yf.Ticker("000001.SZ")
        hist = stock.history(period="5d")
        if not hist.empty:
            print(f"✅ yfinance 工作正常，获取了 {len(hist)} 条数据")
            return True
        else:
            print("❌ yfinance 返回空数据")
            return False
    except ImportError:
        print("⚠️  yfinance 未安装")
        return False
    except Exception as e:
        print(f"❌ yfinance 测试失败: {e}")
        return False

def create_test_script():
    """创建一个测试脚本"""
    test_code = '''
# test_stock_data.py
from akshare_enhanced import get_stock_history, get_stock_pool, get_stock_info
import pandas as pd

print("🧪 测试股票数据获取...")

# 测试1: 获取股票基本信息
print("\\n1. 测试股票基本信息获取:")
symbols = ['000001', '000858', '002594', '300750']
for symbol in symbols:
    info = get_stock_info(symbol)
    print(f"   {symbol}: {info.get('name')} - 价格: {info.get('current_price')}")

# 测试2: 获取历史数据
print("\\n2. 测试历史数据获取:")
symbol = '000001'
hist_data = get_stock_history(symbol, days=30)
if hist_data is not None:
    print(f"   ✅ 成功获取 {len(hist_data)} 条数据")
    print(f"   最新日期: {hist_data['日期'].iloc[-1] if '日期' in hist_data.columns else 'N/A'}")
    print(f"   最新价格: {hist_data['收盘'].iloc[-1] if '收盘' in hist_data.columns else 'N/A'}")
else:
    print("   ❌ 历史数据获取失败")

# 测试3: 获取股票池
print("\\n3. 测试股票池获取:")
pool = get_stock_pool()
if pool is not None:
    print(f"   ✅ 成功获取 {len(pool)} 只股票")
    print(f"   前5只股票:")
    print(pool.head())
else:
    print("   ❌ 股票池获取失败")
    '''
    
    with open('test_stock_data.py', 'w', encoding='utf-8') as f:
        f.write(test_code)
    
    print("📝 创建测试脚本: test_stock_data.py")

def main():
    print("🔧 开始修复数据获取问题...")
    
    # 1. 安装必要包
    install_packages()
    
    # 2. 测试包
    akshare_ok = test_akshare()
    yfinance_ok = test_yfinance()
    
    # 3. 创建测试脚本
    create_test_script()
    
    print("\n🎯 修复完成！请运行以下命令测试：")
    print("  python3 test_stock_data.py")
    print("\n💡 如果数据获取仍然失败，请检查：")
    print("  1. 网络连接")
    print("  2. 是否在交易时间（A股交易时间: 9:30-11:30, 13:00-15:00）")
    print("  3. 可能需要使用代理（已在代码中启用）")

if __name__ == "__main__":
    main()