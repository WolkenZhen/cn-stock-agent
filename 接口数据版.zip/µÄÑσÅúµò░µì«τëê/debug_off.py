# debug_off.py - 快速关闭调试模式
import os

def disable_debug():
    """关闭调试模式"""
    config_path = "config.py"
    
    with open(config_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 将 DEBUG_MODE 设置为 False
    new_content = content.replace("DEBUG_MODE = True", "DEBUG_MODE = False")
    
    with open(config_path, 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    print("✅ 调试模式已关闭")

if __name__ == "__main__":
    disable_debug()