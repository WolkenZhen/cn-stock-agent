# test_fixed_data.py
from akshare_enhanced import get_stock_history, get_stock_pool, get_stock_info
import pandas as pd

def test_fixed_data():
    print("🧪 测试修复后的数据获取...")
    
    # 测试1: 获取股票基本信息
    print("\n1. 测试股票基本信息获取:")
    symbols = ['000001', '000858', '002594', '300750']
    
    for symbol in symbols:
        info = get_stock_info(symbol)
        print(f"   {symbol}: {info.get('name')} - 价格: {info.get('current_price')}")
    
    # 测试2: 获取历史数据
    print("\n2. 测试历史数据获取:")
    symbol = '000001'  # 平安银行
    hist_data = get_stock_history(symbol, days=30)
    
    if hist_data is not None and not hist_data.empty:
        print(f"   ✅ 成功获取 {symbol} 的历史数据")
        print(f"   数据形状: {hist_data.shape}")
        print(f"   列名: {list(hist_data.columns)}")
        print(f"   最新5条数据:")
        print(hist_data.tail())
    else:
        print(f"   ❌ 无法获取 {symbol} 的历史数据")
        print("   💡 尝试另一种方法...")
        # 尝试用更少的天数
        hist_data = get_stock_history(symbol, days=10)
        if hist_data is not None:
            print(f"   ✅ 成功获取 {len(hist_data)} 条数据")
    
    # 测试3: 获取股票池
    print("\n3. 测试股票池获取:")
    pool = get_stock_pool()
    
    if pool is not None and not pool.empty:
        print(f"   ✅ 成功获取股票池数据")
        print(f"   股票数量: {len(pool)}")
        print(f"   深A主板(00开头)数量: {len(pool[pool['代码'].str.startswith('00')])}")
        print(f"   前5只深A主板股票:")
        deep_a = pool[pool['代码'].str.startswith('00')].head()
        print(deep_a[['代码', '名称', '涨跌幅', '成交额']])
    else:
        print("   ❌ 无法获取股票池数据")
    
    print("\n🧪 测试完成！")

if __name__ == "__main__":
    test_fixed_data()