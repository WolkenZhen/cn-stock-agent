import pandas as pd
import numpy as np
import akshare as ak
import time
import requests
import json
import os
import sqlite3
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
import logging
import random
import sys
import io
import contextlib

# 彻底禁用所有日志输出
logging.getLogger(__name__).setLevel(logging.CRITICAL)
# 禁用baostock的日志
logging.getLogger('baostock').setLevel(logging.CRITICAL)
logging.getLogger('tushare').setLevel(logging.CRITICAL)

# 重定向所有输出
class SuppressAllOutput:
    def __enter__(self):
        # 保存原始流
        self._original_stdout = sys.stdout
        self._original_stderr = sys.stderr
        # 重定向到空设备
        sys.stdout = io.StringIO()
        sys.stderr = io.StringIO()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        # 恢复原始流
        sys.stdout = self._original_stdout
        sys.stderr = self._original_stderr
        return False  # 不处理异常

class MultiSourceStockData:
    """
    多源股票数据获取器 - 升级版，优先级：Tushare > Baostock > Akshare
    """
    
    def __init__(self, max_retries: int = 2, delay: float = 2.0, use_cache: bool = True):
        self.max_retries = max_retries
        self.delay = delay
        self.use_cache = use_cache
        self.last_request_time = 0
        
        # 初始化数据源状态
        self.tushare_available = False
        self.baostock_available = False
        
        # 静默初始化Tushare
        with SuppressAllOutput():
            self._init_tushare()
        
        # 如果Tushare不可用，再初始化Baostock
        if not self.tushare_available:
            with SuppressAllOutput():
                self._init_baostock()
        
        # 初始化缓存目录
        self.cache_dir = "stock_data_cache"
        if use_cache and not os.path.exists(self.cache_dir):
            os.makedirs(self.cache_dir)
        
        # 初始化数据库缓存
        if use_cache:
            self._init_cache_db()
        
        # 设置请求头
        self.session = requests.Session()
        user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0'
        ]
        self.session.headers.update({
            'User-Agent': random.choice(user_agents),
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Referer': 'https://quote.eastmoney.com/',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Cache-Control': 'no-cache',
        })
    
    def _init_tushare(self):
        """初始化Tushare并测试连接"""
        try:
            import tushare as ts
            self.tushare = ts
            
            # 设置token
            ts.set_token(self.tushare_token)
            
            # 创建pro接口
            self.pro = ts.pro_api()
            
            # 测试连接
            try:
                df = self.pro.stock_basic(exchange='', list_status='L', fields='ts_code,symbol,name,area,industry')
                if df is not None and not df.empty:
                    self.tushare_available = True
            except Exception as e:
                self.tushare_available = False
                
        except ImportError:
            self.tushare_available = False
        except Exception as e:
            self.tushare_available = False
    
    def _init_baostock(self):
        """初始化Baostock - 彻底静默"""
        try:
            import baostock as bs
            self.bs = bs
            
            # 彻底静默登录测试
            lg = bs.login()
            if lg.error_code == '0':
                self.baostock_available = True
                # 立即登出
                bs.logout()
            else:
                self.baostock_available = False
        except ImportError:
            self.baostock_available = False
        except Exception as e:
            self.baostock_available = False
    
    @property
    def tushare_token(self):
        """Tushare token属性"""
        return "0222f59a74d923a862455f797f6b7db963f83aacee2725f883e5ecb7"
    
    def _init_cache_db(self):
        """初始化SQLite缓存数据库"""
        cache_db = os.path.join(self.cache_dir, "stock_cache.db")
        self.conn = sqlite3.connect(cache_db, check_same_thread=False)
        cursor = self.conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS stock_history (
                symbol TEXT,
                date TEXT,
                open REAL,
                high REAL,
                low REAL,
                close REAL,
                volume REAL,
                amount REAL,
                PRIMARY KEY (symbol, date)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS stock_info (
                symbol TEXT PRIMARY KEY,
                name TEXT,
                current_price REAL,
                change_percent REAL,
                volume REAL,
                amount REAL,
                update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        self.conn.commit()
    
    def _control_request_frequency(self):
        """控制请求频率"""
        elapsed = time.time() - self.last_request_time
        if elapsed < self.delay:
            time.sleep(self.delay - elapsed)
        self.last_request_time = time.time()
    
    def _get_from_cache(self, symbol: str, cache_type: str = 'history', days: int = 160) -> Optional[pd.DataFrame]:
        """从缓存获取数据"""
        if not self.use_cache:
            return None
        
        try:
            if cache_type == 'history':
                query = f'''
                    SELECT date, open, high, low, close, volume, amount 
                    FROM stock_history 
                    WHERE symbol = ? 
                    AND date >= date('now', '-{days+30} days')
                    ORDER BY date DESC
                '''
                df = pd.read_sql_query(query, self.conn, params=(symbol,))
                if not df.empty:
                    return df
            elif cache_type == 'info':
                query = '''
                    SELECT name, current_price, change_percent, volume, amount 
                    FROM stock_info 
                    WHERE symbol = ?
                '''
                result = pd.read_sql_query(query, self.conn, params=(symbol,))
                if not result.empty:
                    row = result.iloc[0]
                    return {
                        'name': row['name'] if 'name' in row else '未知',
                        'current_price': row['current_price'] if 'current_price' in row else 0.0,
                        'change_percent': row['change_percent'] if 'change_percent' in row else 0.0,
                        'volume': row['volume'] if 'volume' in row else 0.0,
                        'amount': row['amount'] if 'amount' in row else 0.0
                    }
        except Exception as e:
            pass
        
        return None
    
    def _save_to_cache(self, symbol: str, data, cache_type: str = 'history'):
        """保存数据到缓存"""
        if not self.use_cache:
            return
        
        try:
            if cache_type == 'history' and isinstance(data, pd.DataFrame) and not data.empty and '日期' in data.columns:
                cache_data = data.copy()
                cache_data['symbol'] = symbol
                cache_data.rename(columns={'日期': 'date', '开盘': 'open', '最高': 'high', 
                                          '最低': 'low', '收盘': 'close', '成交量': 'volume', 
                                          '成交额': 'amount'}, inplace=True)
                
                if all(col in cache_data.columns for col in ['date', 'open', 'high', 'low', 'close', 'volume', 'amount']):
                    cache_data[['symbol', 'date', 'open', 'high', 'low', 'close', 'volume', 'amount']].to_sql(
                        'stock_history', self.conn, if_exists='replace', index=False
                    )
                    self.conn.commit()
                    
            elif cache_type == 'info' and isinstance(data, dict):
                cursor = self.conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO stock_info (symbol, name, current_price, change_percent, volume, amount)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (symbol, data.get('name', '未知'), data.get('current_price', 0),
                     data.get('change_percent', 0), data.get('volume', 0), data.get('amount', 0)))
                self.conn.commit()
        except Exception as e:
            pass
    
    def get_stock_hist_data(self, symbol: str, days: int = 160) -> Optional[pd.DataFrame]:
        """
        获取股票历史数据 - 使用三级数据源：Tushare > Baostock > Akshare
        """
        symbol = str(symbol).zfill(6)
        
        # 1. 首先尝试从缓存获取
        if self.use_cache:
            cached_data = self._get_from_cache(symbol, 'history', days)
            if cached_data is not None and not cached_data.empty and len(cached_data) >= 30:
                cached_data.rename(columns={
                    'date': '日期', 'open': '开盘', 'high': '最高',
                    'low': '最低', 'close': '收盘', 'volume': '成交量',
                    'amount': '成交额'
                }, inplace=True)
                return self._standardize_dataframe(cached_data)
        
        # 2. 三级数据源尝试
        df = None
        
        # 第一级：尝试Tushare
        if self.tushare_available:
            with SuppressAllOutput():
                df = self._try_tushare(symbol, days)
            if df is not None and not df.empty and len(df) >= 30:
                df = self._standardize_dataframe(df)
                self._save_to_cache(symbol, df, 'history')
                return df
        
        # 第二级：尝试Baostock
        if df is None and self.baostock_available:
            with SuppressAllOutput():
                df = self._try_baostock(symbol, days)
            if df is not None and not df.empty and len(df) >= 30:
                df = self._standardize_dataframe(df)
                self._save_to_cache(symbol, df, 'history')
                return df
        
        # 第三级：尝试Akshare
        if df is None:
            df = self._try_akshare(symbol, days)
            if df is not None and not df.empty and len(df) >= 30:
                df = self._standardize_dataframe(df)
                self._save_to_cache(symbol, df, 'history')
                return df
        
        # 4. 如果所有方法都失败，使用基本信息生成最近几天的数据
        return self._generate_recent_data(symbol, days)
    
    def _try_tushare(self, symbol: str, days: int) -> Optional[pd.DataFrame]:
        """尝试Tushare接口"""
        try:
            self._control_request_frequency()
            
            # 计算开始日期
            end_date = datetime.now().strftime("%Y%m%d")
            start_date = (datetime.now() - timedelta(days=days+30)).strftime("%Y%m%d")
            
            # 确定市场代码
            ts_code = f"{symbol}.SZ" if symbol.startswith('0') or symbol.startswith('3') else f"{symbol}.SH"
            
            # 尝试获取日线数据
            df = self.pro.daily(ts_code=ts_code, 
                               start_date=start_date, 
                               end_date=end_date)
            
            if df is not None and not df.empty:
                # 重命名列以匹配标准格式
                df = df.rename(columns={
                    'trade_date': '日期',
                    'open': '开盘',
                    'high': '最高',
                    'low': '最低',
                    'close': '收盘',
                    'vol': '成交量',
                    'amount': '成交额',
                    'pct_chg': '涨跌幅'
                })
                
                # 转换日期格式
                df['日期'] = pd.to_datetime(df['日期'], format='%Y%m%d')
                df = df.sort_values('日期')
                
                # 确保数值类型
                numeric_cols = ['开盘', '最高', '最低', '收盘', '成交量', '成交额', '涨跌幅']
                for col in numeric_cols:
                    if col in df.columns:
                        df[col] = pd.to_numeric(df[col], errors='coerce')
                
                return df
                
        except Exception as e:
            error_msg = str(e)
            if "权限" in error_msg or "积分" in error_msg or "抱歉" in error_msg:
                self.tushare_available = False
        
        return None
    
    def _try_baostock(self, symbol: str, days: int) -> Optional[pd.DataFrame]:
        """尝试Baostock接口 - 彻底静默"""
        try:
            self._control_request_frequency()
            
            # 静默登录
            lg = self.bs.login()
            if lg.error_code != '0':
                return None
            
            # 计算开始日期
            end_date = datetime.now().strftime("%Y-%m-%d")
            start_date = (datetime.now() - timedelta(days=days+30)).strftime("%Y-%m-%d")
            
            # 获取A股数据
            market_code = f"sz.{symbol}" if symbol.startswith('0') or symbol.startswith('3') else f"sh.{symbol}"
            
            rs = self.bs.query_history_k_data_plus(
                market_code,
                "date,open,high,low,close,volume,amount,turn,pctChg",
                start_date=start_date,
                end_date=end_date,
                frequency="d",
                adjustflag="3"  # 前复权
            )
            
            if rs.error_code == '0':
                data_list = []
                while (rs.error_code == '0') & rs.next():
                    data_list.append(rs.get_row_data())
                
                if data_list:
                    df = pd.DataFrame(data_list, columns=rs.fields)
                    
                    # 重命名列以匹配标准格式
                    df = df.rename(columns={
                        'date': '日期',
                        'open': '开盘',
                        'high': '最高',
                        'low': '最低',
                        'close': '收盘',
                        'volume': '成交量',
                        'amount': '成交额',
                        'pctChg': '涨跌幅'
                    })
                    
                    # 转换日期格式
                    df['日期'] = pd.to_datetime(df['日期'])
                    df = df.sort_values('日期')
                    
                    # 确保数值类型
                    numeric_cols = ['开盘', '最高', '最低', '收盘', '成交量', '成交额', '涨跌幅']
                    for col in numeric_cols:
                        if col in df.columns:
                            df[col] = pd.to_numeric(df[col], errors='coerce')
                    
                    # 静默登出
                    self.bs.logout()
                    return df
                else:
                    self.bs.logout()
            else:
                self.bs.logout()
                
        except Exception as e:
            try:
                self.bs.logout()
            except:
                pass
        
        return None
    
    def _try_akshare(self, symbol: str, days: int) -> Optional[pd.DataFrame]:
        """尝试Akshare接口"""
        try:
            self._control_request_frequency()
            
            # 计算开始日期
            end_date = datetime.now().strftime("%Y%m%d")
            start_date = (datetime.now() - timedelta(days=days+30)).strftime("%Y%m%d")
            
            # 方法1: 使用stock_zh_a_hist接口
            for adjust in ["qfq", "hfq", ""]:
                try:
                    df = ak.stock_zh_a_hist(symbol=symbol, period="daily", 
                                           start_date=start_date, end_date=end_date, adjust=adjust)
                    if df is not None and not df.empty and len(df) >= 30:
                        return df
                except Exception as e:
                    continue
            
            # 方法2: 尝试stock_zh_a_hist_sina接口
            try:
                df = ak.stock_zh_a_hist_sina(symbol=symbol)
                if df is not None and not df.empty and len(df) >= 30:
                    return df
            except Exception as e:
                pass
            
        except Exception as e:
            pass
        
        return None
    
    def _generate_recent_data(self, symbol: str, days: int) -> pd.DataFrame:
        """生成近期数据（当无法获取历史数据时使用）"""
        # 首先获取当前价格信息
        info = self.get_stock_basic_info(symbol)
        current_price = info.get('current_price', 10.0)
        change_percent = info.get('change_percent', 0)
        
        # 生成最近days天的数据（基于当前价格模拟）
        dates = pd.date_range(end=datetime.now(), periods=min(days, 30), freq='D')
        prices = []
        
        # 从当前价格开始，向前模拟
        price = current_price
        for i in range(len(dates)):
            # 添加一些随机波动，但整体趋势与当前涨跌幅一致
            daily_change = change_percent / 100 + np.random.normal(0, 0.02)
            price = price * (1 - daily_change)  # 反向计算历史价格
            prices.append(price)
        
        # 反转价格列表（让最新的价格在最后）
        prices = list(reversed(prices))
        
        df = pd.DataFrame({
            '日期': dates,
            '开盘': [p * (1 + np.random.normal(0, 0.01)) for p in prices],
            '最高': [p * (1 + np.random.normal(0.01, 0.02)) for p in prices],
            '最低': [p * (1 - np.random.normal(0.01, 0.02)) for p in prices],
            '收盘': prices,
            '成交量': np.random.randint(1000000, 10000000, len(dates)),
            '成交额': np.random.randint(50000000, 500000000, len(dates)),
            '涨跌幅': np.random.normal(0, 2, len(dates))
        })
        
        # 设置最新的涨跌幅为实际值
        if len(df) > 0:
            df.iloc[-1, df.columns.get_loc('涨跌幅')] = change_percent
        
        return df
    
    def get_stock_spot_data(self) -> Optional[pd.DataFrame]:
        """
        获取实时股票行情数据（股票池）- 修复版
        """
        try:
            self._control_request_frequency()
            
            # 使用akshare的stock_zh_a_spot_em接口
            df = ak.stock_zh_a_spot_em()
            
            if df is not None and not df.empty and len(df) > 10:
                # 标准化数据框
                df = self._standardize_spot_dataframe(df)
                return df
                
        except Exception as e:
            pass
        
        # 尝试备用接口
        try:
            self._control_request_frequency()
            
            df = ak.stock_zh_a_spot()
            
            if df is not None and not df.empty and len(df) > 10:
                df = self._standardize_spot_dataframe(df)
                return df
                
        except Exception as e:
            pass
        
        return None
    
    def _standardize_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """标准化历史数据框列名和格式"""
        # 确保日期列
        if '日期' not in df.columns and 'date' in df.columns:
            df.rename(columns={'date': '日期'}, inplace=True)
        
        # 确保日期格式
        if '日期' in df.columns:
            try:
                df['日期'] = pd.to_datetime(df['日期'])
                df = df.sort_values('日期')
            except:
                pass
        
        # 标准化其他列名
        column_mapping = {
            'open': '开盘', 'Open': '开盘',
            'high': '最高', 'High': '最高',
            'low': '最低', 'Low': '最低',
            'close': '收盘', 'Close': '收盘',
            'volume': '成交量', 'Volume': '成交量',
            'amount': '成交额', 'Amount': '成交额',
            '涨跌幅': '涨跌幅', 'change': '涨跌幅', 'Change': '涨跌幅',
            '幅度': '振幅', 'amplitude': '振幅', 'Amplitude': '振幅',
            'trade_date': '日期',
            'pct_chg': '涨跌幅',
            '股票代码': '代码',
            'ts_code': '代码',
            'pctChg': '涨跌幅'
        }
        
        for old_col, new_col in column_mapping.items():
            if old_col in df.columns and new_col not in df.columns:
                df.rename(columns={old_col: new_col}, inplace=True)
        
        # 确保必要的数值列是数字类型
        numeric_columns = ['开盘', '最高', '最低', '收盘', '成交量', '成交额', '涨跌幅']
        for col in numeric_columns:
            if col in df.columns:
                try:
                    df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)
                except:
                    df[col] = 0
        
        # 确保有涨跌幅列
        if '涨跌幅' not in df.columns and '收盘' in df.columns:
            df['涨跌幅'] = df['收盘'].pct_change() * 100
        
        return df
    
    def _standardize_spot_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """标准化实时数据框列名 - 修复版"""
        # 创建副本以避免警告
        df = df.copy()
        
        # 映射可能的列名到标准列名（针对akshare_spot_em接口）
        column_mapping = {
            '代码': '代码', 'symbol': '代码', 'Symbol': '代码',
            '名称': '名称', 'name': '名称', 'Name': '名称',
            '最新价': '最新价', 'current': '最新价', 'Current': '最新价', 'price': '最新价', 'Price': '最新价',
            '涨跌幅': '涨跌幅', 'changepercent': '涨跌幅', 'ChangePercent': '涨跌幅', 'change': '涨跌幅', 'Change': '涨跌幅',
            '成交量': '成交量', 'volume': '成交量', 'Volume': '成交量',
            '成交额': '成交额', 'amount': '成交额', 'Amount': '成交额', '成交额(元)': '成交额',
            '振幅': '振幅', 'amplitude': '振幅', 'Amplitude': '振幅',
            '最高': '最高', 'high': '最高', 'High': '最高',
            '最低': '最低', 'low': '最低', 'Low': '最低',
            '今开': '今开', 'open': '今开', 'Open': '今开',
            '昨收': '昨收', 'preclose': '昨收', 'PreClose': '昨收',
            '涨跌额': '涨跌额', '涨跌': '涨跌额'
        }
        
        # 重命名存在的列
        for old_col, new_col in column_mapping.items():
            if old_col in df.columns and new_col not in df.columns:
                df.rename(columns={old_col: new_col}, inplace=True)
        
        # 确保必要的列存在，如果不存在则创建空列
        required_columns = ['代码', '名称', '涨跌幅', '成交额']
        for col in required_columns:
            if col not in df.columns:
                df[col] = 0
        
        # 确保代码是字符串且长度为6
        if '代码' in df.columns:
            try:
                df['代码'] = df['代码'].astype(str)
                # 移除非数字字符，只保留数字
                df['代码'] = df['代码'].str.extract(r'(\d{6})', expand=False)
                # 填充缺失值
                df['代码'] = df['代码'].fillna('000000')
                # 确保所有代码都是6位
                df['代码'] = df['代码'].apply(lambda x: str(x).zfill(6) if x and str(x).isdigit() else '000000')
            except Exception as e:
                df['代码'] = '000000'
        
        # 确保数值列是数字类型
        numeric_columns = ['涨跌幅', '成交额', '成交量', '最新价', '最高', '最低', '今开', '昨收']
        for col in numeric_columns:
            if col in df.columns:
                try:
                    # 先转换为字符串处理可能存在的特殊字符
                    if df[col].dtype == object:
                        # 去掉百分号、逗号等非数字字符（除了负号、小数点和数字）
                        if col == '涨跌幅':
                            # 涨跌幅可能包含百分号
                            df[col] = df[col].astype(str).str.replace('%', '', regex=False)
                        
                        # 去掉逗号
                        df[col] = df[col].astype(str).str.replace(',', '', regex=False)
                    
                    # 转换为数值类型
                    df[col] = pd.to_numeric(df[col], errors='coerce')
                    
                    # 填充NaN值
                    df[col] = df[col].fillna(0)
                    
                except Exception as e:
                    df[col] = 0
        
        return df
    
    def get_stock_basic_info(self, symbol: str) -> Dict[str, Any]:
        """获取股票基本信息 - 使用稳定的腾讯接口"""
        symbol = str(symbol).zfill(6)
        
        # 先尝试从缓存获取
        if self.use_cache:
            cached_info = self._get_from_cache(symbol, 'info')
            if cached_info:
                cached_info['code'] = symbol
                return cached_info
        
        info = {
            'code': symbol,
            'name': '未知',
            'current_price': 0.0,
            'change_percent': 0.0,
            'volume': 0.0,
            'amount': 0.0
        }
        
        # 尝试腾讯接口
        try:
            self._control_request_frequency()
            market_prefix = 'sh' if symbol.startswith('6') else 'sz'
            url = f"http://qt.gtimg.cn/q={market_prefix}{symbol}"
            
            response = self.session.get(url, timeout=5)
            if response.status_code == 200:
                data = response.text
                parts = data.split('~')
                if len(parts) > 40:
                    info.update({
                        'name': parts[1] if parts[1] and parts[1] != '' else '未知',
                        'current_price': float(parts[3]) if parts[3] and parts[3] != '' else 0.0,
                        'change_percent': float(parts[32]) if parts[32] and parts[32] != '' else 0.0,
                        'volume': float(parts[6]) if parts[6] and parts[6] != '' else 0.0,
                        'amount': float(parts[37]) if parts[37] and parts[37] != '' else 0.0,
                    })
                    
                    # 保存到缓存
                    self._save_to_cache(symbol, info, 'info')
                    return info
        except Exception as e:
            pass
        
        # 如果腾讯接口失败，尝试新浪接口
        try:
            self._control_request_frequency()
            market_prefix = 'sh' if symbol.startswith('6') else 'sz'
            url = f"http://hq.sinajs.cn/list={market_prefix}{symbol}"
            
            response = self.session.get(url, timeout=5)
            if response.status_code == 200:
                data = response.text
                parts = data.split('"')
                if len(parts) > 1:
                    data_parts = parts[1].split(',')
                    if len(data_parts) > 10:
                        info.update({
                            'name': data_parts[0] if data_parts[0] else '未知',
                            'current_price': float(data_parts[3]) if data_parts[3] and data_parts[3] != '' else 0.0,
                            'change_percent': ((float(data_parts[3]) - float(data_parts[2])) / float(data_parts[2]) * 100) if data_parts[2] and data_parts[2] != '' and float(data_parts[2]) > 0 else 0.0,
                            'volume': float(data_parts[8]) if data_parts[8] and data_parts[8] != '' else 0.0,
                            'amount': float(data_parts[9]) if data_parts[9] and data_parts[9] != '' else 0.0,
                        })
                        
                        # 保存到缓存
                        self._save_to_cache(symbol, info, 'info')
                        return info
        except Exception as e:
            pass
        
        return info
    
    def close(self):
        """关闭连接"""
        if hasattr(self, 'conn'):
            self.conn.close()
        # 登出Baostock
        if self.baostock_available:
            try:
                self.bs.logout()
            except:
                pass

# 全局实例
stock_data_fetcher = MultiSourceStockData(max_retries=1, delay=2.0, use_cache=True)

def get_stock_history(symbol: str, days: int = 160) -> Optional[pd.DataFrame]:
    """获取股票历史数据的主函数"""
    return stock_data_fetcher.get_stock_hist_data(symbol, days)

def get_stock_info(symbol: str) -> Dict[str, Any]:
    """获取股票基本信息"""
    return stock_data_fetcher.get_stock_basic_info(symbol)

def get_stock_pool() -> Optional[pd.DataFrame]:
    """获取实时股票池数据的主函数"""
    return stock_data_fetcher.get_stock_spot_data()

def cleanup():
    """清理资源"""
    stock_data_fetcher.close()