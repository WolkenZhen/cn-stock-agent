# debug_on.py - 快速开启调试模式
import os

def enable_debug():
    """开启调试模式"""
    config_path = "config.py"
    
    with open(config_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 将 DEBUG_MODE 设置为 True
    new_content = content.replace("DEBUG_MODE = False", "DEBUG_MODE = True")
    
    with open(config_path, 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    print("✅ 调试模式已开启")
    print("💡 运行完毕后，请运行 debug_off.py 关闭调试模式")

if __name__ == "__main__":
    enable_debug()