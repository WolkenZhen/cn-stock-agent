# requirements_upgrade.py
import subprocess
import sys

def install_packages():
    packages = [
        'yfinance',      # 备用数据源
        'sqlite3',       # 缓存数据库（Python自带）
        'pandas>=1.5.0',
        'numpy>=1.24.0',
        'akshare>=1.12.0',
        'requests>=2.28.0',
         'tushare>=1.2.89',
          'baostock>=0.8.10',
    ]
    
    for package in packages:
        try:
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', package])
            print(f"✅ 成功安装 {package}")
        except subprocess.CalledProcessError:
            print(f"❌ 安装 {package} 失败")
            if package == 'yfinance':
                print("   💡 yfinance 是可选的备用数据源")

if __name__ == "__main__":
    print("正在安装/升级依赖包...")
    install_packages()
    print("✅ 依赖包安装完成！")