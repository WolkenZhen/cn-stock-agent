# main_test.py
from akshare_enhanced import get_stock_history, get_stock_pool, get_stock_info
import pandas as pd

def test_data_fetcher():
    print("🧪 测试数据获取器...")
    
    # 测试1: 获取股票基本信息
    print("\n1. 测试获取股票基本信息...")
    symbols = ['000001', '000858', '002594', '300750']
    
    for symbol in symbols:
        info = get_stock_info(symbol)
        print(f"   {symbol}: {info.get('name')} - 价格: {info.get('current_price')}")
    
    # 测试2: 获取历史数据
    print("\n2. 测试获取历史数据...")
    symbol = '000001'  # 平安银行
    hist_data = get_stock_history(symbol, days=30)
    
    if hist_data is not None and not hist_data.empty:
        print(f"   ✅ 成功获取 {symbol} 的历史数据")
        print(f"   数据形状: {hist_data.shape}")
        print(f"   最新日期: {hist_data['日期'].iloc[-1] if '日期' in hist_data.columns else 'N/A'}")
        print(f"   最新价格: {hist_data['收盘'].iloc[-1] if '收盘' in hist_data.columns else 'N/A'}")
    else:
        print(f"   ❌ 无法获取 {symbol} 的历史数据")
    
    # 测试3: 获取股票池
    print("\n3. 测试获取股票池...")
    pool = get_stock_pool()
    
    if pool is not None and not pool.empty:
        print(f"   ✅ 成功获取股票池数据")
        print(f"   股票数量: {len(pool)}")
        print(f"   列名: {list(pool.columns)}")
        print(f"   前5只股票:")
        print(pool[['代码', '名称', '涨跌幅', '成交额']].head())
    else:
        print("   ❌ 无法获取股票池数据")
        print("   💡 可能原因:")
        print("     1. 非交易时间 (A股交易时间: 9:30-11:30, 13:00-15:00)")
        print("     2. 网络连接问题")
        print("     3. 数据源API限制")
    
    print("\n🧪 测试完成！")

if __name__ == "__main__":
    test_data_fetcher()