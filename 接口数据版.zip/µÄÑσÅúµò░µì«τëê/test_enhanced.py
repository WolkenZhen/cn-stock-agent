# test_enhanced.py
from akshare_enhanced import get_stock_history, get_stock_pool, get_stock_info
import pandas as pd

print("🧪 测试增强版数据获取...")

# 测试1: 获取股票基本信息
print("\n1. 测试股票基本信息获取:")
symbols = ['000001', '002545', '000858', '300750']

for symbol in symbols:
    info = get_stock_info(symbol)
    print(f"   {symbol}: {info.get('name')} - 价格: {info.get('current_price')} - 涨跌幅: {info.get('change_percent')}%")

# 测试2: 获取历史数据
print("\n2. 测试历史数据获取:")
symbol = '002545'  # 东方铁塔
hist_data = get_stock_history(symbol, days=30)

if hist_data is not None and not hist_data.empty:
    print(f"   ✅ 成功获取 {symbol} 的历史数据")
    print(f"   数据形状: {hist_data.shape}")
    print(f"   列名: {list(hist_data.columns)}")
    print(f"   日期范围: {hist_data['日期'].iloc[0]} 到 {hist_data['日期'].iloc[-1]}")
    print(f"   最新价格: {hist_data['收盘'].iloc[-1] if '收盘' in hist_data.columns else 'N/A'}")
else:
    print(f"   ❌ 无法获取 {symbol} 的历史数据")

# 测试3: 获取股票池
print("\n3. 测试股票池获取:")
pool = get_stock_pool()

if pool is not None and not pool.empty:
    print(f"   ✅ 成功获取股票池数据")
    print(f"   股票数量: {len(pool)}")
    
    # 显示深A主板股票
    deep_a = pool[pool['代码'].str.startswith('00')]
    print(f"   深A主板(00开头)数量: {len(deep_a)}")
    
    if len(deep_a) > 0:
        print(f"   前5只深A主板股票:")
        print(deep_a[['代码', '名称', '涨跌幅', '成交额']].head())
else:
    print("   ❌ 无法获取股票池数据")

print("\n🧪 测试完成！")