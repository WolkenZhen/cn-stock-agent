import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time

# 导入新的数据获取模块
from akshare_enhanced import get_stock_history, get_stock_info

class TradingSignalGenerator:
    def __init__(self, stock_code: str):
        self.stock_code = str(stock_code).zfill(6)
        self.stock_data = None
        self.last_fetch_time = None

    def fetch_stock_data(self):
        """获取股票历史数据 - 静默模式"""
        # 避免频繁调用
        if self.last_fetch_time and (datetime.now() - self.last_fetch_time).seconds < 10:
            if self.stock_data is not None and len(self.stock_data) > 10:
                return
        
        # 使用新的多源数据获取器
        self.stock_data = get_stock_history(self.stock_code, days=160)
        
        if self.stock_data is not None and len(self.stock_data) >= 10:
            self.last_fetch_time = datetime.now()

    def get_indicators(self):
        """计算技术指标"""
        if self.stock_data is None or len(self.stock_data) < 10:
            # 尝试重新获取数据
            self.fetch_stock_data()
            if self.stock_data is None or len(self.stock_data) < 10:
                return self._get_simple_indicators()
        
        df = self.stock_data.copy()
        
        # 确保数据排序
        if '日期' in df.columns:
            try:
                df = df.sort_values('日期')
            except:
                pass
        
        try:
            curr = df.iloc[-1]
        except:
            return self._get_simple_indicators()
        
        # 1. 量价爆发因子
        f1 = 40  # 基础分
        
        # 计算成交量比率
        if '成交量' in df.columns:
            try:
                vol_5d = df['成交量'].tail(min(5, len(df)))
                if len(vol_5d) > 0 and vol_5d.mean() > 0:
                    vol_ratio = curr['成交量'] / vol_5d.mean()
                    if 1.5 < vol_ratio < 4:
                        f1 += 30
                    elif vol_ratio >= 4:
                        f1 += 20
                else:
                    f1 += 10
            except:
                f1 += 10
        
        # 计算涨跌幅
        if '涨跌幅' in df.columns:
            try:
                price_change = float(curr['涨跌幅'])
                if price_change > 9.7:
                    f1 = 10  # 涨停不追
                elif price_change > 5:
                    f1 += 50
            except:
                pass
        
        # 判断是否接近20日高点
        if '收盘' in df.columns and len(df) >= 20:
            try:
                high_20d = df['收盘'].iloc[-min(20, len(df)):-1].max() if len(df) > 1 else df['收盘'].iloc[0]
                if float(curr['收盘']) > high_20d * 0.98:
                    f1 += 20
            except:
                pass
        
        # 2. 趋势强度
        if '收盘' in df.columns and len(df) >= 20:
            try:
                ma20 = df['收盘'].rolling(20).mean().iloc[-1]
                f2 = 100 if curr['收盘'] > ma20 else 30
            except:
                f2 = 50
        else:
            f2 = 50
        
        # 3. 资金流向
        if '最高' in df.columns and '最低' in df.columns and '收盘' in df.columns:
            try:
                price_range = curr['最高'] - curr['最低']
                if price_range > 0:
                    strength = (curr['收盘'] - curr['最低']) / price_range
                else:
                    strength = 0.5
                f3 = strength * 100
            except:
                f3 = 50
        else:
            f3 = 50
        
        # 4. 基本面安全垫
        f4 = 60
        if '收盘' in df.columns and curr['收盘'] > 3:
            f4 += 20
        
        if '涨跌幅' in df.columns:
            try:
                min_5d_change = df['涨跌幅'].tail(5).min() if len(df) >= 5 else 0
                if min_5d_change > -7:
                    f4 += 20
            except:
                pass

        return {
            "量价爆发": round(f1, 1),
            "趋势强度": round(f2, 1),
            "资金流向": round(f3, 1),
            "基本面安全垫": f4
        }
    
    def _get_simple_indicators(self):
        """获取简化指标（当数据不足时）"""
        # 获取基本信息
        info = get_stock_info(self.stock_code)
        current_price = info.get('current_price', 0)
        change_percent = info.get('change_percent', 0)
        
        # 基于基本信息计算简化指标
        f1 = 40  # 基础分
        
        if change_percent > 9.7:
            f1 = 10
        elif change_percent > 5:
            f1 += 50
        elif change_percent > 1.5:
            f1 += 30
        
        # 趋势强度（假设上涨趋势）
        f2 = 100 if change_percent > 0 else 30
        
        # 资金流向（中性）
        f3 = 50
        
        # 基本面安全垫
        f4 = 60
        if current_price > 3:
            f4 += 20
        
        return {
            "量价爆发": round(f1, 1),
            "趋势强度": round(f2, 1),
            "资金流向": round(f3, 1),
            "基本面安全垫": f4
        }

    def calculate_logic(self, weights=None):
        """计算交易逻辑 - 增强版，添加T+1到T+3价格"""
        # 首先尝试获取基本信息
        info = get_stock_info(self.stock_code)
        price = info.get('current_price', 0)
        
        # 如果价格无效，尝试从stock_data获取
        if price <= 0 and self.stock_data is not None and not self.stock_data.empty:
            if '收盘' in self.stock_data.columns:
                price = self.stock_data['收盘'].iloc[-1]
        
        if price <= 0:
            price = 10.0  # 默认价格
        
        # 计算ATR（简化版）
        if self.stock_data is not None and len(self.stock_data) >= 14:
            try:
                # 计算真实波幅
                df = self.stock_data.copy()
                if all(col in df.columns for col in ['最高', '最低', '收盘']):
                    tr = np.maximum(
                        df['最高'] - df['最低'],
                        np.maximum(
                            abs(df['最高'] - df['收盘'].shift(1)),
                            abs(df['最低'] - df['收盘'].shift(1))
                        )
                    )
                    atr = tr.tail(14).mean()
                else:
                    atr = price * 0.03
            except:
                atr = price * 0.03
        else:
            atr = price * 0.03
        
        atr = max(atr, price * 0.01)
        
        # 计算MA5
        if self.stock_data is not None and len(self.stock_data) >= 5 and '收盘' in self.stock_data.columns:
            try:
                ma5 = self.stock_data['收盘'].rolling(5).mean().iloc[-1]
            except:
                ma5 = price
        else:
            ma5 = price
        
        # 计算近期波动率
        if self.stock_data is not None and '收盘' in self.stock_data.columns and len(self.stock_data) >= 10:
            returns = self.stock_data['收盘'].pct_change().dropna()
            volatility = returns.std() * np.sqrt(252)  # 年化波动率
            daily_volatility = volatility / np.sqrt(252)  # 日波动率
        else:
            daily_volatility = 0.02  # 默认2%日波动率
        
        # 委托买入价
        entrust_buy = round(max(price * 0.99, ma5 * 0.995), 2)
        
        # 根据量价爆发因子调整止盈比例
        profit_ratio = 1.2
        if isinstance(weights, dict):
            if weights.get("量价爆发", 0) > 35:
                profit_ratio = 2.0
            elif weights.get("量价爆发", 0) > 30:
                profit_ratio = 1.5
        
        # 计算T+1到T+3目标价
        t1_target = round(price * (1 + profit_ratio * daily_volatility), 2)
        t2_target = round(price * (1 + 1.5 * profit_ratio * daily_volatility), 2)
        t3_target = round(price * (1 + 2.0 * profit_ratio * daily_volatility), 2)
        
        # 动态止盈
        t1_sell_target = round(price + profit_ratio * atr, 2)
        
        # 止损价
        if self.stock_data is not None and '最低' in self.stock_data.columns and len(self.stock_data) > 0:
            try:
                last_low = self.stock_data['最低'].iloc[-1]
                stop_loss = round(min(price - 0.8 * atr, last_low * 0.98), 2)
            except:
                stop_loss = round(price * 0.95, 2)
        else:
            stop_loss = round(price * 0.95, 2)
        
        return {
            'price': round(price, 2),
            'entrust_buy': entrust_buy,
            'target_t1': t1_target,
            'target_t2': t2_target,
            'target_t3': t3_target,
            'stop_loss': stop_loss,
            'atr': round(atr, 2),
            'volatility': round(daily_volatility * 100, 2)  # 转换为百分比
        }