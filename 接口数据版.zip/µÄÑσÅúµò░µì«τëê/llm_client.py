import json, re
import akshare as ak
from openai import OpenAI  # 需要安装openai包: pip install openai

# LLM配置
LLM_CONFIG = {
    "api_url": "https://api.deepseek.com/chat/completions",
    "api_key": "sk-a84f7971d767458cafeb3e757612ea16", 
    "model_name": "deepseek-chat",
}

class FreeLLMClient:
    def __init__(self):
        # 使用OpenAI客户端配置
        self.client = OpenAI(
            api_key=LLM_CONFIG["api_key"],
            base_url=LLM_CONFIG["api_url"].replace("/chat/completions", "")  # 移除末尾路径
        )
        self.model_name = LLM_CONFIG["model_name"]
        self.expert_persona = """您是一位专业的中国股市分析师，专门分析A股、港股等中国资本市场。您具备深厚的中国股市知识和丰富的本土投资经验。

您的专业领域包括：
1. **A股市场分析**: 深度理解A股的独特性，包括涨跌停制度、T+1交易、融资融券等
2. **中国经济政策**: 熟悉货币政策、财政政策对股市的影响机制
3. **行业板块轮动**: 掌握中国特色的板块轮动规律和热点切换
4. **监管环境**: 了解证监会政策、退市制度、注册制等监管变化
5. **市场情绪**: 理解中国投资者的行为特征和情绪波动

分析重点：
- **技术面分析**: 使用通达信数据进行精确的技术指标分析
- **基本面分析**: 结合中国会计准则和财报特点进行分析
- **政策面分析**: 评估政策变化对个股和板块的影响
- **资金面分析**: 分析北向资金、融资融券、大宗交易等资金流向
- **市场风格**: 判断当前是成长风格还是价值风格占优

中国股市特色考虑：
- 涨跌停板限制对交易策略的影响
- ST股票的特殊风险和机会
- 科创板、创业板的差异化分析
- 国企改革、混改等主题投资机会
- 中美关系、地缘政治对中概股的影响

作为A股短线量化基金经理，您擅长通过盘面细节捕捉市场情绪，进行精准的短线博弈。"""

    def _call_llm(self, prompt, system=None):
        """调用DeepSeek API"""
        system_msg = system if system else self.expert_persona
        
        try:
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=[
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                stream=False
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"🚨 DeepSeek API调用失败: {e}")
            return None

    def fetch_market_analysis(self):
        """全方位大盘扫描：双重热点源 + 容错推演 - 增强版"""
        sectors, status = ["未知"], "震荡整理"
        try:
            # 1. 获取上证指数数据
            index_df = ak.stock_zh_index_daily(symbol="sh000001")
            if len(index_df) < 2:
                return ["未知"], "数据不足，无法分析"
            
            last_close = index_df['close'].iloc[-1]
            prev_close = index_df['close'].iloc[-2]
            pct_change = (last_close / prev_close - 1) * 100
            
            # 2. 获取热点板块数据
            top_industries = []
            try:
                ind_df = ak.stock_board_industry_spot_em()
                if ind_df is not None and not ind_df.empty:
                    # 查找涨跌幅列
                    change_col = None
                    for col in ind_df.columns:
                        if '涨跌幅' in col or 'change' in col.lower():
                            change_col = col
                            break
                    
                    if change_col:
                        ind_df = ind_df.sort_values(by=change_col, ascending=False).head(5)
                        if '板块名称' in ind_df.columns:
                            top_industries = ind_df['板块名称'].tolist()
                        elif 'name' in ind_df.columns:
                            top_industries = ind_df['name'].tolist()
            except Exception as e:
                pass
            
            # 3. 获取个股数据用于补充分析
            hot_stocks = []
            try:
                pool = ak.stock_zh_a_spot_em()
                if pool is not None and not pool.empty:
                    # 按涨跌幅排序
                    pool_sorted = pool.sort_values(by='涨跌幅', ascending=False).head(10)
                    if '名称' in pool_sorted.columns:
                        hot_stocks = pool_sorted['名称'].head(3).tolist()
            except Exception as e:
                pass
            
            # 4. 构建详细的提示词
            prompt = f"""
            【实时A股市场数据】
            上证指数：{last_close:.2f}点 (涨跌幅 {pct_change:.2f}%)
            
            【市场热点信息】
            领涨板块：{', '.join(top_industries) if top_industries else '暂无明确领涨板块'}
            强势个股：{', '.join(hot_stocks) if hot_stocks else '无明显强势个股'}
            
            【深度分析任务】
            请作为资深A股分析师，对当前市场进行深度分析：
            
            1. **市场状态判断**：
               - 指数位置与趋势（高位/低位，上升/下降通道）
               - 成交量与资金活跃度
               - 技术指标信号（MACD，KDJ等）
            
            2. **情绪与风格分析**：
               - 当前市场情绪（贪婪/恐惧/观望）
               - 主导风格（成长/价值/题材/周期）
               - 赚钱效应（好/一般/差）
            
            3. **热点与机会识别**：
               - 提炼3-5个当前最热门的短线题材关键词
               - 分析这些热点的持续性和风险
            
            4. **操作策略建议**：
               - 明确建议：进攻、防守、或观望
               - 具体仓位建议：几成仓位
               - 风险提示与操作纪律
            
            【输出格式要求】
            请严格按照以下格式输出：
            
            ###市场状态###: [用一句话总结当前市场核心特征，如：放量突破/缩量整理/破位下跌等]
            ###操作策略###: [进攻/防守/观望] | [仓位：X成] | [核心逻辑：一句话说明原因]
            ###热点题材###: [关键词1],[关键词2],[关键词3],[关键词4],[关键词5]
            ###详细分析###: 
            [这里详细展开分析，包括：
            1. 技术面分析
            2. 资金面分析  
            3. 情绪面分析
            4. 具体操作建议
            5. 风险提示]
            """
            
            res = self._call_llm(prompt)
            if res:
                # 解析响应
                sectors, status = self._parse_market_response(res)
            else:
                # 使用备用分析
                if pct_change > 1:
                    status = f"指数上涨{pct_change:.2f}%，市场活跃 | 建议：谨慎进攻 | 仓位：5成"
                    sectors = ["指数权重", "大金融", "科技龙头"] if not top_industries else top_industries[:3]
                elif pct_change < -1:
                    status = f"指数下跌{abs(pct_change):.2f}%，市场低迷 | 建议：防守 | 仓位：3成"
                    sectors = ["防御板块", "高股息", "消费"] if not top_industries else top_industries[:3]
                else:
                    status = f"指数震荡{pct_change:.2f}%，多空平衡 | 建议：观望 | 仓位：4成"
                    sectors = ["热点轮动", "中小盘", "题材股"] if not top_industries else top_industries[:3]
                
        except Exception as e:
            # 出错时的默认值
            status = "数据获取异常，建议谨慎 | 建议：观望 | 仓位：3成"
            sectors = ["待确认"]
            
        return sectors, status
    
    def _parse_market_response(self, response: str):
        """解析LLM的市场分析响应"""
        sectors = ["未知"]
        status = "震荡整理"
        
        try:
            # 提取市场状态
            if "###市场状态###:" in response:
                status_part = response.split("###市场状态###:")[1].split("###")[0].strip()
                status = status_part
            
            # 提取操作策略
            if "###操作策略###:" in response:
                strategy_part = response.split("###操作策略###:")[1].split("###")[0].strip()
                status = strategy_part
            
            # 提取热点题材
            if "###热点题材###:" in response:
                sectors_part = response.split("###热点题材###:")[1].split("###")[0].strip()
                sectors = [s.strip() for s in sectors_part.split(",") if s.strip()]
            
            # 如果解析失败，尝试从响应中提取关键词
            if sectors == ["未知"]:
                # 尝试提取看起来像板块的关键词
                import re
                keywords = re.findall(r'[A-Za-z0-9\u4e00-\u9fa5]{2,6}股|[A-Za-z0-9\u4e00-\u9fa5]{2,8}板块|[A-Za-z0-9\u4e00-\u9fa5]{2,6}概念', response)
                if keywords:
                    sectors = list(set(keywords[:5]))
            
        except Exception as e:
            pass
        
        return sectors, status

    def get_ai_expert_factor(self, stock_info):
        """AI 专家打分 - 结合中国特色分析"""
        prompt = f"""
        请对以下A股个股进行波段潜力诊断，寻找3-5天持续性标的。排除涨停标的。
        
        【个股数据】：{stock_info}
        
        【分析要求】：
        1. 结合中国股市特色（涨跌停限制、T+1等）进行分析
        2. 考虑当前市场风格（成长/价值）
        3. 评估政策面和资金面影响
        4. 给出短线（3-5天）技术面判断
        
        请返回JSON格式：{{"score": 85, "reason": "xxx", "alpha": 10}}
        - score: 综合评分（0-100）
        - reason: 分析理由（包含技术面、资金面、政策面分析）
        - alpha: 超额收益预期（-20到+20）
        """
        res = self._call_llm(prompt)
        try:
            match = re.search(r'\{.*\}', res, re.DOTALL)
            data = json.loads(match.group())
            return data.get("score", 60), data.get("reason", "形态良好"), data.get("alpha", 0)
        except Exception as e:
            print(f"⚠️ AI专家因子解析失败: {e}")
            return 60, "量化趋势稳健", 0

    def optimize_weights_deep_evolution(self, history_data, current_weights, market_context):
        """权重进化优化 - 结合中国特色"""
        prompt = f"""
        【今日市场环境】{market_context}
        
        【历史战报】{history_data}
        
        【当前权重】{json.dumps(current_weights)}
        
        【任务】：
        根据历史盈亏和当前A股市场特性，自适应调整权重因子分配。
        请综合考虑：
        1. 当前市场风格（成长/价值/题材）
        2. 资金面状况（北向资金、两融数据）
        3. 技术面特征（突破/震荡/回调）
        4. 政策面影响
        
        只返回JSON格式的权重字典，各因子权重总和为100。
        """
        res = self._call_llm(prompt)
        try:
            match = re.search(r'\{.*\}', res, re.DOTALL)
            return json.loads(match.group())
        except Exception as e:
            print(f"⚠️ 权重优化解析失败: {e}")
            return current_weights