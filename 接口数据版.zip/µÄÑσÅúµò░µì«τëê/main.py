import argparse
import pandas as pd
import time
from trading_signal import TradingSignalGenerator
from llm_client import FreeLLMClient
from akshare_enhanced import get_stock_info, get_stock_history

def get_stock_name(stock_code: str) -> str:
    """获取股票名称 - 使用多源数据获取器"""
    try:
        # 方法1: 使用多源数据获取器的基本信息接口
        info = get_stock_info(stock_code)
        if info and info.get('name') != '未知':
            return info['name']
        
        # 方法2: 备用方法 - 尝试其他接口
        code = str(stock_code).zfill(6)
        
        # 尝试通过腾讯接口获取
        try:
            import akshare as ak
            # 使用股票列表接口
            stock_list = ak.stock_info_a_code_name()
            if code in stock_list['code'].values:
                return stock_list[stock_list['code'] == code]['name'].iloc[0]
        except:
            pass
        
        # 尝试通过历史数据获取（如果有）
        try:
            df = get_stock_history(code, days=5)
            if df is not None and not df.empty:
                # 如果历史数据中有名称信息，尝试提取
                if '名称' in df.columns:
                    return df['名称'].iloc[-1]
        except:
            pass
        
        return f"未知个股({code})"
        
    except Exception as e:
        print(f"获取股票名称失败: {e}")
        return f"未知个股({stock_code})"

def analyze_single_stock(stock_code: str, cost_price=None):
    # 打印开始信息
    print(f"🔍 开始分析股票 {stock_code}...")
    
    # 1. 初始化信号生成器并获取数据
    tsg = TradingSignalGenerator(stock_code)
    
    # 增加重试机制
    max_retries = 3
    for retry in range(max_retries):
        try:
            print(f"📥 尝试获取数据 (第 {retry+1} 次)...")
            tsg.fetch_stock_data()
            
            if tsg.stock_data is not None and not tsg.stock_data.empty:
                print(f"✅ 数据获取成功，共 {len(tsg.stock_data)} 条记录")
                break
            else:
                print(f"⚠️  第 {retry+1} 次获取数据失败，数据为空")
                if retry < max_retries - 1:
                    print(f"⏳ 等待 2 秒后重试...")
                    time.sleep(2)
        except Exception as e:
            print(f"❌ 获取数据异常 (尝试 {retry+1}/{max_retries}): {e}")
            if retry < max_retries - 1:
                print(f"⏳ 等待 2 秒后重试...")
                time.sleep(2)
    
    # 2. 获取计算逻辑
    res = tsg.calculate_logic(cost_price)
    
    if not res or tsg.stock_data is None or tsg.stock_data.empty:
        print(f"❌ 无法获取股票 {stock_code} 的完整数据，尝试使用基本信息...")
        
        # 尝试使用基本信息生成简化报告
        info = get_stock_info(stock_code)
        name = info.get('name', f"未知({stock_code})")
        price = info.get('current_price', 0)
        
        if price > 0:
            print(f"\n🚀 [AI 深度个股诊断] {name}({stock_code})")
            print(f"   状态: 数据获取受限，使用基本信息分析")
            print(f"   现价: {price}")
            print(f"   涨跌幅: {info.get('change_percent', 0):.2f}%")
            print(f"   成交额: {info.get('amount', 0):.0f}")
            print("-" * 70)
            print("⚠️  [注意] 技术指标数据不足，建议:")
            print("    1. 稍后重试（数据接口可能临时限制）")
            print("    2. 检查股票代码是否正确")
            print("    3. 手动查看该股票的实时行情")
            print("-" * 70)
        else:
            print(f"❌ 完全无法获取股票 {stock_code} 的任何数据")
            print("💡 可能原因：")
            print("   1. 股票代码不存在或已退市")
            print("   2. 网络连接问题")
            print("   3. 数据源接口全部受限")
            print("   4. 非交易时间")
        return

    # 3. 补全技术指标
    df = tsg.stock_data
    
    # 确保必要的列存在
    if '最低' not in df.columns or '最高' not in df.columns or '收盘' not in df.columns:
        print("❌ 数据格式不完整，缺少必要列")
        return
    
    try:
        low_160 = df['最低'].min()
        high_160 = df['最高'].max()
        curr_price = df['收盘'].iloc[-1]
        
        # 计算位阶
        if high_160 != low_160:
            position_pct = round((curr_price - low_160) / (high_160 - low_160) * 100, 1)
        else:
            position_pct = 50
        
        # 计算近期支撑与阻力
        support = df['最低'].tail(10).min()
        
        # 关键修改：如果现价已经接近或超过近期高点，阻力位应向上看高一线
        resistance_raw = df['最高'].tail(10).max()
        
        # 判断是否为突破形态
        is_breakout = False
        status_desc = "通道内震荡"
        
        if curr_price >= resistance_raw * 0.99:
            is_breakout = True
            status_desc = "🔥 强势突破/主升浪阶段"
            resistance = "上方无套牢盘 (天空)"
        else:
            resistance = resistance_raw

        name = get_stock_name(stock_code)
        
        # --- 打印诊断结果 ---
        print(f"\n🚀 [AI 深度个股诊断] {name}({stock_code})")
        print(f"   状态: {status_desc}")
        print(f"   现价: {res['price']} | 位阶: {position_pct}%")
        print(f"   支撑: {support:.2f} | 阻力: {resistance}")
        print(f"   数据周期: {len(df)} 天 | 最新日期: {df['日期'].iloc[-1].strftime('%Y-%m-%d') if '日期' in df.columns else '未知'}")
        print("-" * 70)
        
        # --- 持仓管理建议 ---
        if cost_price:
            profit = (res['price'] / float(cost_price) - 1) * 100
            print(f"🏮 【持仓建议】")
            print(f"   >>> 当前成本: {cost_price} | 当前盈亏: {profit:.2f}%")
            print(f"   >>> 建议止盈参考: {res['target']} | 动态止损线: {res['stop_loss']}")
        else:
            print(f"💡 【持仓管理提示】")
            print(f"   >>> 若需针对性卖出建议，请带参数运行: --cost [你的成本价]")
        
        print("-" * 70)
        print(f"🎯 【交易参考】")
        print(f"   >>> 当日建议买入委托价: {res['entrust_buy']}")
        print(f"   >>> 止盈目标: {res['target']} | 止损参考: {res['stop_loss']}")
        print(f"   >>> ATR波动率: {res.get('atr', 'N/A')}")
        print("-" * 70)

        # 4. 调用 DeepSeek 专家点评
        print("🧠 DeepSeek 专家点评：")
        llm = FreeLLMClient()
        
        # 构造更聪明的提示词，解决"恐高"问题
        if is_breakout:
            strategy_hint = "该股处于强势突破阶段，位阶较高是正常的动量特征。请重点分析上涨空间的持续性，不要仅仅因为位阶高就建议卖出。重点关注是否为真突破。"
        else:
            strategy_hint = "该股处于震荡区间，请基于支撑阻力位给出高抛低吸建议。"

        diagnose_prompt = f"""
        请对 {name}({stock_code}) 进行专家级简评。
        【技术数据】：现价{res['price']}, 历史位阶{position_pct}%, 近期支撑{support:.2f}。
        【形态判断】：{status_desc}。
        【特别指示】：{strategy_hint}
        
        请输出：
        1. 【{name}走势研判】：分析是主升浪开启还是顶部风险。
        2. 【操作策略】：针对激进型（追涨）和稳健型（回调买）投资者的不同建议。
        建议输出格式清晰，分段明确。
        """
        
        try:
            analysis = llm._call_llm(diagnose_prompt)
            if analysis:
                print(analysis)
            else:
                print("   >>> 暂时无法获取 AI 点评，请检查 API 配置。")
        except Exception as e:
            print(f"   >>> AI 点评获取失败: {e}")
            print("   💡 提示: 请检查网络连接和DeepSeek API配置")
            
    except Exception as e:
        print(f"❌ 数据处理出错: {e}")
        print("💡 可能原因：数据格式异常或计算错误")

def main():
    parser = argparse.ArgumentParser(
        description='A股个股深度诊断工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  python3 main.py --code 002998              # 分析002998
  python3 main.py --code 000001 --cost 12.5  # 分析000001，成本价12.5元
  
股票代码格式: 6位数字，如 000001, 002998, 300750 等
        """
    )
    parser.add_argument('--code', type=str, required=True, 
                       help='股票代码，6位数字，如 002498')
    parser.add_argument('--cost', type=float, 
                       help='持仓成本价，用于计算盈亏和提供卖出建议')
    
    args = parser.parse_args()
    
    # 检查股票代码格式
    code = str(args.code).strip()
    if not code.isdigit() or len(code) != 6:
        print(f"❌ 股票代码格式错误: {code}，应为6位数字")
        print("   例如: 002998 (荣科科技), 000001 (平安银行)")
        return
    
    print(f"📈 A股个股深度诊断工具")
    print(f"   分析股票: {code}")
    if args.cost:
        print(f"   持仓成本: {args.cost}")
    print("=" * 60)
    
    analyze_single_stock(code, args.cost)

if __name__ == "__main__":
    main()