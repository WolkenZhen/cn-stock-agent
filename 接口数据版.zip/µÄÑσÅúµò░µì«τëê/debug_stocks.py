# debug_stocks.py
from akshare_enhanced import get_stock_pool, get_stock_history, get_stock_info
import pandas as pd
import re

def debug_stock_pool():
    print("🔍 诊断股票池数据...")
    
    # 获取股票池
    pool = get_stock_pool()
    
    if pool is None or pool.empty:
        print("❌ 无法获取股票池")
        return
    
    print(f"✅ 股票池数据形状: {pool.shape}")
    print(f"📊 列名: {list(pool.columns)}")
    
    # 检查代码列
    print("\n🔍 分析代码列...")
    if '代码' in pool.columns:
        pool['代码'] = pool['代码'].astype(str)
        
        # 统计不同类型代码
        digit_codes = pool[pool['代码'].str.match(r'^\d{6}$')]
        print(f"  6位纯数字代码数量: {len(digit_codes)}")
        
        # 深A主板 (00开头)
        deep_a = digit_codes[digit_codes['代码'].str.startswith('00')]
        print(f"  深A主板(00开头)数量: {len(deep_a)}")
        
        # 打印前20个深A主板股票
        if len(deep_a) > 0:
            print(f"\n📊 前20个深A主板股票:")
            print(deep_a[['代码', '名称', '涨跌幅', '成交额']].head(20).to_string())
        else:
            print("⚠️ 未找到深A主板股票")
            
            # 显示所有数字代码
            print(f"\n📊 所有6位数字代码:")
            print(digit_codes[['代码', '名称']].head(20).to_string())
    
    # 检查数据类型
    print("\n🔍 检查数据列类型...")
    for col in pool.columns:
        sample = pool[col].iloc[0] if len(pool) > 0 else None
        print(f"  {col}: {type(sample)}, 示例: {sample}")
    
    # 检查深A主板具体数据
    print("\n🔍 深A主板股票详细分析...")
    if len(deep_a) > 0:
        # 分析涨跌幅分布
        if '涨跌幅' in deep_a.columns:
            deep_a['涨跌幅'] = pd.to_numeric(deep_a['涨跌幅'], errors='coerce')
            print(f"  涨跌幅范围: {deep_a['涨跌幅'].min():.2f}% 到 {deep_a['涨跌幅'].max():.2f}%")
            print(f"  涨跌幅>1.5%的数量: {(deep_a['涨跌幅'] > 1.5).sum()}")
            print(f"  涨跌幅<9.7%的数量: {(deep_a['涨跌幅'] < 9.7).sum()}")
        
        # 分析成交额分布
        if '成交额' in deep_a.columns:
            deep_a['成交额'] = pd.to_numeric(deep_a['成交额'], errors='coerce')
            print(f"  成交额范围: {deep_a['成交额'].min():.0f} 到 {deep_a['成交额'].max():.0f}")
            print(f"  成交额>8000万的数量: {(deep_a['成交额'] > 80000000).sum()}")
    
    # 测试几个具体股票
    print("\n🔍 测试具体股票获取...")
    test_codes = ['000001', '000002', '000858']
    for code in test_codes:
        print(f"\n  测试 {code}:")
        info = get_stock_info(code)
        print(f"    名称: {info.get('name')}")
        print(f"    价格: {info.get('current_price')}")
        print(f"    涨跌幅: {info.get('change_percent')}%")

if __name__ == "__main__":
    debug_stock_pool()